//Task5: Fix Exception Handling in DocumentValidator

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DocumentValidator {
    private static final Logger logger = LoggerFactory.getLogger(DocumentValidator.class);

    public ValidationResult validate(Document doc) {
        try {
            if (doc == null) {
                // FIX: Specific exception for validation failure
                throw new IllegalArgumentException("Document is null");
            }
            String content = doc.extractContent();
            if (content.isEmpty()) {
                // FIX: Specific exception for validation failure
                throw new IllegalArgumentException("Empty content");
            }
            return runValidationRules(content);

        } catch (IllegalArgumentException e) {
            // FIX: Log expected failures at WARN level
            logger.warn("Validation failed: {}", e.getMessage());
            return new ValidationResult(false, e.getMessage()); // FIX: Return meaningful result
        } catch (Exception e) {
            // FIX: Log unexpected errors at ERROR level with stack trace
            logger.error("Unexpected error during validation", e);
            return new ValidationResult(false, "Unexpected error");
        }
    }

    public void validateBatch(List<Document> docs) {
        for (Document doc : docs) {
            try {
                ValidationResult r = validate(doc);
                if (r != null && r.isValid()) { // FIX: Null-check
                    saveResult(r);
                }
            } catch (Exception e) {
                // FIX: Log instead of swallowing
                logger.error("Error validating document in batch", e);
            }
        }
    }
}