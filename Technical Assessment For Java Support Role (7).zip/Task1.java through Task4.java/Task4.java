//Task4: Fix Connection Leak in ReportDAO

public List<ReportEntry> fetchMonthlyReport(String accountId, int month, int year) throws SQLException {
    // FIX: Use try-with-resources for Connection, PreparedStatement, ResultSet
    try (Connection conn = dataSource.getConnection();
         PreparedStatement ps = conn.prepareStatement(
             "SELECT * FROM report_entries " +
             "WHERE account_id = ? AND MONTH(entry_date) = ? " +
             "AND YEAR(entry_date) = ?"
         )) {

        ps.setString(1, accountId);
        ps.setInt(2, month);
        ps.setInt(3, year);

        try (ResultSet rs = ps.executeQuery()) {
            List<ReportEntry> entries = new ArrayList<>();
            while (rs.next()) {
                entries.add(mapRow(rs));
            }
            return entries;
        }
    }
}
