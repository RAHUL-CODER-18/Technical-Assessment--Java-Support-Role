# Analysis.md — Task 2

## 1. Cause of ConcurrentModificationException
Occurs when a collection is structurally modified while iterating with a fail‑fast iterator (e.g., ArrayList).

## 2. Code Pattern at Line 142
Removing elements directly from the list inside a loop:
```java
for (Transaction t : transactions) {
    if (/* condition */) {
        transactions.remove(t); // triggers ConcurrentModificationException
    }
}

## 3. Minimal Safe Fix
Use the iterator’s own remove() method:

Iterator<Transaction> it = transactions.iterator();
while (it.hasNext()) {
    Transaction t = it.next();
    if (/* condition */) {
        it.remove(); // safe removal
    }
}