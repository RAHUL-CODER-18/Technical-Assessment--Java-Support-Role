Task1: Fix LoanAccountService.getOverdueLoans()


public List<LoanAccount> getOverdueLoans(List<LoanAccount> accounts) {
    // FIX: Initialize result list to avoid NullPointerException
    List<LoanAccount> result = new ArrayList<>();

    // FIX: Null-check for accounts list
    if (accounts == null) {
        return result;
    }

    Date today = new Date(); // FIX: Avoid repeated new Date()

    for (LoanAccount account : accounts) {
        // FIX: Null-check dueDate
        if (account.getDueDate() != null && account.getDueDate().before(today)) {
            // FIX: Exclude zero balance accounts
            if (account.getOutstandingBalance() > 0) {
                result.add(account);
            }
        }
    }
    return result;
}
