Task2: Diagnose ConcurrentModificationException


Cause: Structural modification of a collection (like ArrayList) while iterating with a fail‑fast iterator.

Pattern at line 142: Removing elements directly from the list inside a for-each or iterator loop.

Minimal fix: Use it.remove() instead of list.remove(t):


Iterator<Transaction> it = transactions.iterator();
while (it.hasNext()) {
    Transaction t = it.next();
    if (/* condition */) {
        it.remove(); // FIX
    }
}
